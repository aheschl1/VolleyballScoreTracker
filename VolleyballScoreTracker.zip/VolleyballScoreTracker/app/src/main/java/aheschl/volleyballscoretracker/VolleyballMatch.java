package aheschl.volleyballscoretracker;

abstract class VolleyballMatch {

    abstract void homeScoreUp(MainActivity mainActivity);
    abstract void awayScoreUp(MainActivity mainActivity);
    abstract void awayScoreDown(MainActivity mainActivity);
    abstract void homeScoreDown(MainActivity mainActivity);
    abstract int getHomeScore();
    abstract int getAwayScore();
    abstract void setHomeScore(int homeScore);
    abstract void setAwayScore(int awayScore);

}
