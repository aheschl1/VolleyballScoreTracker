package aheschl.volleyballscoretracker;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;

import java.util.ArrayList;
import java.util.Arrays;

import yuku.ambilwarna.AmbilWarnaDialog;

public class MainActivity extends AppCompatActivity implements View.OnTouchListener{

    Button homeButton;
    Button awayButton;

    int homeButtonIndex = 0;

    Vibrator vibrator;

    MySharedPreferences mySharedPreferences;
    SetHistoryShared setHistoryShared;

    ImageView rightIndicator;
    ImageView leftIndicator;

    CheckBox homeTimeout1;
    CheckBox homeTimeout2;
    CheckBox awayTimeout1;
    CheckBox awayTimeout2;

    LinearLayout bottomLeftView;
    LinearLayout bottomRightView;

    boolean timeoutsReversed = false;

    LinearLayout bottomView;
    LinearLayout homeTimeoutLinear;
    LinearLayout awayTimeoutLinear;
    LinearLayout homeSets;
    LinearLayout awaySets;
    LinearLayout buttonsLayout;
    LinearLayout homeButtonLinear;
    LinearLayout awayButtonLinear;

    TextView homeTeamName;
    TextView awayTeamName;

    TextView homeSetNumber;
    TextView awaySetNumber;

    Button homeButton2;

    GestureDetector awayButtonDetector;

    GestureDetector homeButtonDetector;

    ArrayList<String> undoHistory;

    Animation slideUpHome;

    Animation slideDownHome;

    Button awayScore2;

    Animation slideDownAway;
    Animation slideUpAway;

    TextView setNumber;

    VolleyballMatch VBMatch;

    private FirebaseAnalytics mFirebaseAnalytics;

    Switch myPlayer;
    ImageButton textPlayerOnOff;
    EditText playerName;

    Switch serverSwitch;
    private boolean serverSwitchListen = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        buttonsLayout = findViewById(R.id.buttons);

        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        mySharedPreferences = new MySharedPreferences(this);

        setHistoryShared = new SetHistoryShared(this);

        homeButtonIndex = mySharedPreferences.getHomeButtonIndex();

        undoHistory = new ArrayList<>();

        if(mySharedPreferences.getTypeOfVolleyball() == Constants.INDOOR) {
            VBMatch = new IndoorVolleyball();
        }else{
            VBMatch = new BeachVolleyball();
        }


        initServerSwitch();

        prepareActionBar();

        initScores();

        initScoreButtons();

        initSwitchSides();

        initTimeouts();

        initSetDisplay();

        initNameDisplay();

        initSetNumber();

        showSetHistory();

        initMyPlayerSwitch();

    }

    private void initServerSwitch() {

        serverSwitch = findViewById(R.id.server);

        serverSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {

            if(serverSwitchListen) {
                if (isChecked) {
                    mySharedPreferences.setServer(Constants.AWAY);
                } else {
                    mySharedPreferences.setServer(Constants.HOME);
                }

                setServer();
            }

        });

    }

    @Override
    protected void onResume() {

        homeTeamName.setText(String.valueOf(mySharedPreferences.getHomeTeamName()));
        awayTeamName.setText(String.valueOf(mySharedPreferences.getAwayTeamName()));

        setNumber.setText(String.valueOf(getSetNum()));

        initButtonColors();

        RelativeLayout parent = null;
        LinearLayout playerLinear = null;

        boolean finish;

        try {
            parent = findViewById(R.id.parent);
            playerLinear = findViewById(R.id.playerInfoLinear);
            finish = true;
        }catch(NullPointerException e){
            finish = false;
        }

        if(finish && mySharedPreferences.getPlayerInfoOn() == Constants.OFF){
            parent.removeView(playerLinear);
        }else if(finish && parent.getChildCount() == 6){

            parent.addView(playerLinear);
            initMyPlayerSwitch();

        }

        super.onResume();
    }

    private void initMyPlayerSwitch() {

        try {
            myPlayer = findViewById(R.id.myPlayerOnOff);
            textPlayerOnOff = findViewById(R.id.sendOnOff);
            playerName = findViewById(R.id.playerName);
        }catch (NullPointerException ignored){}

        if(myPlayer != null && textPlayerOnOff != null && playerName != null){

            String onOff = mySharedPreferences.getMyPlayer();

            if(onOff.equals(Constants.stringON)){
                myPlayer.setChecked(true);
            }

            playerName.setText(mySharedPreferences.getPlayerName());

            playerName.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }
                @Override
                public void afterTextChanged(Editable s) {
                    mySharedPreferences.setPlayerName(s.toString());
                }
            });

            textPlayerOnOff.setOnClickListener(v -> sendPlayerOnOff());

            myPlayer.setOnCheckedChangeListener((compoundButton, checked) -> {

                if(checked){
                    mySharedPreferences.setMyPlayer(Constants.stringON);
                }else{
                    mySharedPreferences.setMyPlayer(Constants.stringOFF);
                }

            });

        }

    }

    private void sendPlayerOnOff() {

        sendText(mySharedPreferences.getPlayerName() + " - " + mySharedPreferences.getMyPlayer());

    }

    private void initButtonColors() {

        if(mySharedPreferences.getHomeColor() != Constants.OFF) {
            homeButton.setBackgroundColor(mySharedPreferences.getHomeColor());
            homeButton2.setBackgroundColor(mySharedPreferences.getHomeColor());
        }else{
            homeButton.setBackgroundColor(getResources().getColor(R.color.homeColor));
            homeButton2.setBackgroundColor(getResources().getColor(R.color.homeColor));
        }

        if(mySharedPreferences.getAwayColor() != Constants.OFF) {
            awayButton.setBackgroundColor(mySharedPreferences.getAwayColor());
            awayScore2.setBackgroundColor(mySharedPreferences.getAwayColor());
        }else{
            awayButton.setBackgroundColor(getResources().getColor(R.color.awayColor));
            awayScore2.setBackgroundColor(getResources().getColor(R.color.awayColor));
        }

    }

    private void showSetHistory() {

        TextView setHistoryOne = findViewById(R.id.setOneHistoryView);
        TextView setHistoryTwo = findViewById(R.id.setTwoHistoryView);
        TextView setHistoryThree = findViewById(R.id.setThreeHistoryView);
        TextView setHistoryFour = findViewById(R.id.setFourHistoryView);
        TextView setHistoryFive = findViewById(R.id.setFiveHistoryView);

        setHistoryOne.setText(String.valueOf(setHistoryShared.getFirstSetHistory()));
        setHistoryTwo.setText(String.valueOf(setHistoryShared.getSecondSetHistory()));
        setHistoryThree.setText(String.valueOf(setHistoryShared.getThirdSetHistory()));
        setHistoryFour.setText(String.valueOf(setHistoryShared.getFourthSetHistory()));
        setHistoryFive.setText(String.valueOf(setHistoryShared.getFifthSetHistory()));

    }

    public void sendSMSIntent(ArrayList<String> numbers, String body) {

        StringBuilder sb = new StringBuilder();
        for (String s : numbers)
        {
            sb.append(s);
            sb.append("; ");
        }

        Uri uri = Uri.parse("smsto:" + sb);
        Intent smsIntent = new Intent(Intent.ACTION_SENDTO, uri);
        smsIntent.putExtra("sms_body", body);
        startActivity(smsIntent);
    }

    void setServer() {

        if(mySharedPreferences.getServer() == Constants.HOME){

            if(homeButtonIndex == 0) {
                rightIndicator.setVisibility(View.INVISIBLE);

                leftIndicator.setVisibility(View.VISIBLE);
            }else{

                rightIndicator.setVisibility(View.VISIBLE);

                leftIndicator.setVisibility(View.INVISIBLE);

            }

            serverSwitchListen = false;
            serverSwitch.setChecked(false);
            serverSwitchListen = true;

        }else if(mySharedPreferences.getServer() == Constants.AWAY){

            if(homeButtonIndex == 0) {
                rightIndicator.setVisibility(View.VISIBLE);

                leftIndicator.setVisibility(View.INVISIBLE);
            }else{

                rightIndicator.setVisibility(View.INVISIBLE);

                leftIndicator.setVisibility(View.VISIBLE);

            }

            serverSwitchListen = false;
            serverSwitch.setChecked(true);
            serverSwitchListen = true;

        }

    }

    private void initSetNumber() {

        setNumber = findViewById(R.id.setNumber);

        setNumber.setText(String.valueOf(getSetNum()));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.actionbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // action with ID action_refresh was selected
            case R.id.action_reset:

                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Reset Game")
                    .setMessage("Do you really want to reset the match?")
                    .setPositiveButton("Reset", (dialog, whichButton) -> resetGame())

                    .setNegativeButton(android.R.string.no, null).show();
                break;
            case R.id.action_switch_courts:
                changeSides();
                break;
            case R.id.action_sms:
                sendText();
                break;
            case R.id.action_undo:
                undoLastAction();
                break;
            case R.id.action_settings:
                Intent i = new Intent(MainActivity.this, Settings.class);
                startActivity(i);
                finish();
                break;
            case R.id.action_new_set:
                prepareNewSet();
                break;
            case R.id.action_rate:
                launchRate();
                break;
            case R.id.action_coffee:
                Intent i5 = new Intent(MainActivity.this, BuyMeACoffee.class);
                startActivity(i5);
            default:
                break;
        }

        return true;
    }

    private void launchRate() {
        final String appPackageName = getPackageName();
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
        } catch (android.content.ActivityNotFoundException error) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
        }
    }
    private void initNameDisplay() {

        homeTeamName = findViewById(R.id.homeTeamName);
        awayTeamName = findViewById(R.id.awayTeamName);

        homeTeamName.setOnClickListener(view -> {
            Intent i = new Intent(MainActivity.this, ChangeHomeTeamName.class);
            startActivity(i);
        });

        awayTeamName.setOnClickListener(view -> {
            Intent i = new Intent(MainActivity.this, ChangeAwayTeamName.class);
            startActivity(i);
        });

    }

    private void prepareActionBar() {

        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {

            actionBar.setDisplayShowCustomEnabled(true);
            actionBar.setDisplayShowTitleEnabled(false);

        }

    }

    void prepareNewSet() {

        changeSides();

        if(VBMatch.getHomeScore() < VBMatch.getAwayScore()){

            int awaySets = Integer.parseInt(awaySetNumber.getText().toString());

            awaySets++;

            mySharedPreferences.setAwaySetsWon(awaySets);

            if(mySharedPreferences.getSMSPopup() == Constants.ON) {
                sendText(getMessage(mySharedPreferences.getSMSMessagePostSet(), mySharedPreferences.getAwayTeamName(), Constants.SET));
            }else{
                sendTextNoConfirmEndOfSet(Constants.SET, mySharedPreferences.getAwayTeamName());
            }

        }else if( VBMatch.getAwayScore() < VBMatch.getHomeScore()){

            int homeSets = Integer.parseInt(homeSetNumber.getText().toString());

            homeSets++;

            mySharedPreferences.setHomeSetsWon(homeSets);

            homeSetNumber.setText(String.valueOf(homeSets));

            if(mySharedPreferences.getSMSPopup() == Constants.ON) {
                sendText(getMessage(mySharedPreferences.getSMSMessagePostSet(), mySharedPreferences.getHomeTeamName(), Constants.SET));
            }else{
                sendTextNoConfirmEndOfSet(Constants.SET, mySharedPreferences.getHomeTeamName());
            }

        }else{

            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Who Won?")
                    .setMessage("The scores are equal. Who won the set?")
                    .setPositiveButton(String.valueOf(mySharedPreferences.getHomeTeamName()), (dialog, which) -> {

                        int homeSets = Integer.parseInt(homeSetNumber.getText().toString());

                        homeSets++;

                        mySharedPreferences.setHomeSetsWon(homeSets);

                        homeSetNumber.setText(String.valueOf(homeSets));

                        if(mySharedPreferences.getSMSPopup() == Constants.ON) {
                            sendText(String.valueOf(mySharedPreferences.getHomeTeamName()) + " won the set");
                        }else{
                            sendTextNoConfirmEndOfSet(Constants.SET, mySharedPreferences.getHomeTeamName());
                        }

                        setNumber.setText(String.valueOf(getSetNum()));


                    })
                    .setNegativeButton(String.valueOf(mySharedPreferences.getAwayTeamName()), (dialog, which) -> {

                        int awaySets = Integer.parseInt(awaySetNumber.getText().toString());

                        awaySets++;

                        mySharedPreferences.setAwaySetsWon(awaySets);

                        awaySetNumber.setText(String.valueOf(awaySets));

                        if(mySharedPreferences.getSMSPopup() == Constants.ON) {
                            sendText(getMessage(mySharedPreferences.getSMSMessagePostSet(), mySharedPreferences.getAwayTeamName(), Constants.SET));
                        }else{
                            sendTextNoConfirmEndOfSet(Constants.SET, mySharedPreferences.getAwayTeamName());
                        }

                        setNumber.setText(String.valueOf(getSetNum()));

                    }).setCancelable(false)
                    .show();

        }

        if(getSetNum() == 2){
            setHistoryShared.setFirstSetHistory(VBMatch.getHomeScore() + "-" +  VBMatch.getAwayScore());
        }else if(getSetNum() == 3){
            setHistoryShared.setSecondSetHistory(VBMatch.getHomeScore() + "-" +  VBMatch.getAwayScore());
        }else if(getSetNum() == 4){
            setHistoryShared.setThirdSetHistory(VBMatch.getHomeScore() + "-" +  VBMatch.getAwayScore());
        }else if(getSetNum() == 5){
            setHistoryShared.setFourthSetHistory(VBMatch.getHomeScore() + "-" + VBMatch.getAwayScore());
        }

        showSetHistory();

        VBMatch.setHomeScore(0);

        VBMatch.setAwayScore(0);

        mySharedPreferences.setAwayScore(VBMatch.getAwayScore());

        mySharedPreferences.setHomeScore(VBMatch.getHomeScore());

        awayButton.setText(String.valueOf(mySharedPreferences.getAwayScore()));

        homeButton.setText(String.valueOf(mySharedPreferences.getHomeScore()));

        homeTimeout1.setChecked(false);

        homeTimeout2.setChecked(false);

        awayTimeout1.setChecked(false);

        awayTimeout2.setChecked(false);

        setNumber.setText(String.valueOf(getSetNum()));

        homeSetNumber.setText(String.valueOf(mySharedPreferences.getHomeSetsWon()));

        awaySetNumber.setText(String.valueOf(mySharedPreferences.getAwaySetsWon()));

    }

    private String getMessage(String outline, String winningTeam, String setOrMatch){

        if(setOrMatch.equals(Constants.SET)){
            setOrMatch = "set";
        }else{
            setOrMatch = "match";
        }


        String messageWithHome = outline.replaceAll(Constants.HOME_SCORE, String.valueOf(mySharedPreferences.getHomeScore()));

        String messageWithAway = messageWithHome.replaceAll(Constants.AWAY_SCORE, String.valueOf(mySharedPreferences.getAwayScore()));

        int setNum = getSetNum();

        String messageWithSetNum = messageWithAway.replaceAll(Constants.SET, String.valueOf(setNum));

        int homeSetsWon = getHomeSets();

        int awaySetsWon = getAwaySets();

        final String messageWithHomeSets = messageWithSetNum.replaceAll(Constants.HOME_SETS, String.valueOf(homeSetsWon));

        final String messageWithAwaySets = messageWithHomeSets.replaceAll(Constants.AWAY_SETS, String.valueOf(awaySetsWon));

        final String messageWithHomeTeamName = messageWithAwaySets.replaceAll(Constants.HOME_TEAM_NAME, String.valueOf(mySharedPreferences.getHomeTeamName()));

        final String mesageWithAwayTeamName = messageWithHomeTeamName.replaceAll(Constants.AWAY_TEAM_NAME, String.valueOf(mySharedPreferences.getAwayTeamName()));

        final String mesageWithWinningTeam = mesageWithAwayTeamName.replaceAll(Constants.WINNING_TEAM, winningTeam);

        final String mesageWithMyPlayer = mesageWithWinningTeam.replaceAll(Constants.MY_PLAYER, mySharedPreferences.getMyPlayer());

        final String mesageWithMyPlayerName = mesageWithMyPlayer.replaceAll(Constants.PLAYER_NAME, mySharedPreferences.getPlayerName());

        return mesageWithMyPlayerName.replaceAll(Constants.MATCH_OR_SET, setOrMatch);
    }

    private void undoLastAction() {

        String lastAction = "";

        if(undoHistory.size() > 0){
            lastAction = undoHistory.get(undoHistory.size()-1);
            undoHistory.remove(undoHistory.size()-1);
        }

        if(lastAction.equals(Constants.HOME_SCORE)){

           VBMatch.homeScoreDown(MainActivity.this);

        }else if(lastAction.equals(Constants.AWAY_SCORE)){

           VBMatch.awayScoreDown(MainActivity.this);

        }

    }

    private void initSetDisplay() {

        homeSetNumber = findViewById(R.id.homeSetNumber);

        awaySetNumber = findViewById(R.id.awaySetNumber);

        homeSetNumber.setText(String.valueOf(getHomeSets()));

        awaySetNumber.setText(String.valueOf(getAwaySets()));

    }

    private void initTimeouts() {

        homeTimeout1 = findViewById(R.id.homeTimeoutOne);
        homeTimeout2 = findViewById(R.id.homeTimeoutTwo);
        awayTimeout1 = findViewById(R.id.awayTimeoutOne);
        awayTimeout2 = findViewById(R.id.awayTimeoutTwo);

        homeTimeout1.setChecked(mySharedPreferences.getHomeTimeoutOne());
        homeTimeout2.setChecked(mySharedPreferences.getHomeTimeoutTwo());

        awayTimeout1.setChecked(mySharedPreferences.getAwayTimeoutOne());
        awayTimeout2.setChecked(mySharedPreferences.getAwayTimeoutTwo());

        homeTimeout1.setOnCheckedChangeListener((buttonView, isChecked) -> {

            if(isChecked){

                mySharedPreferences.setHomeTimeoutOne(true);

            }else{

                mySharedPreferences.setHomeTimeoutOne(false);

            }

        });

        homeTimeout2.setOnCheckedChangeListener((buttonView, isChecked) -> {

            if(isChecked){

                mySharedPreferences.setHomeTimeoutTwo(true);

            }else{

                mySharedPreferences.setHomeTimeoutTwo(false);

            }

        });

        awayTimeout1.setOnCheckedChangeListener((buttonView, isChecked) -> {

            if(isChecked){

                mySharedPreferences.setAwayTimeoutOne(true);

            }else{

                mySharedPreferences.setAwayTimeoutOne(false);

            }

        });

        awayTimeout2.setOnCheckedChangeListener((buttonView, isChecked) -> {

            if(isChecked){

                mySharedPreferences.setAwayTimeoutTwo(true);

            }else{

                mySharedPreferences.setAwayTimeoutTwo(false);

            }

        });

    }

    private void initSwitchSides() {

        bottomLeftView = findViewById(R.id.bottomLeftView);

        bottomRightView = findViewById(R.id.bottomRightView);

        bottomView = findViewById(R.id.bottomOfLayout);

        awayTimeoutLinear = findViewById(R.id.awayTimeoutLinear);

        homeTimeoutLinear = findViewById(R.id.homeTimeoutLinear);

        homeSets = findViewById(R.id.homeSets);

        awaySets = findViewById(R.id.awaySets);

        homeButtonLinear = findViewById(R.id.homeButtonLinear);

        awayButtonLinear = findViewById(R.id.awayButtonLinear);

        if(homeButtonIndex != 0){
            reverseSides();
        }else{
            setServer();
        }

    }

    private void reverseSides() {

        buttonsLayout.removeViewAt(0);
        buttonsLayout.addView(homeButtonLinear, 1);

        bottomView.removeViewAt(0);

        bottomView.removeViewAt(1);

        bottomView.addView(bottomRightView, 0);

        bottomView.addView(bottomLeftView, 2);


        bottomLeftView.removeViewAt(0);

        bottomLeftView.removeViewAt(0);

        bottomLeftView.addView(homeSets, 0);

        bottomLeftView.addView(homeTimeoutLinear);


        bottomRightView.removeViewAt(0);

        bottomRightView.removeViewAt(0);

        bottomRightView.addView(awayTimeoutLinear, 0);

        bottomRightView.addView(awaySets);

        timeoutsReversed = true;

        setServer();

    }

    void changeSides() {

        if(mySharedPreferences.getVibrate() == Constants.ON) {
            // Vibrate for 500 milliseconds
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                //deprecated in API 26
                vibrator.vibrate(100);
            }
        }

        if(homeButtonIndex == 0){

            buttonsLayout.removeViewAt(0);
            buttonsLayout.addView(homeButtonLinear, 1);

            homeButtonIndex = 1;

        }else{

            buttonsLayout.removeViewAt(1);
            buttonsLayout.addView(homeButtonLinear, 0);

            homeButtonIndex = 0;

        }

        homeButton.setText(String.valueOf(mySharedPreferences.getHomeScore()));

        if(rightIndicator.getVisibility() == View.INVISIBLE){
            rightIndicator.setVisibility(View.VISIBLE);
            leftIndicator.setVisibility(View.INVISIBLE);
        }else{
            rightIndicator.setVisibility(View.INVISIBLE);
            leftIndicator.setVisibility(View.VISIBLE);
        }

        if(!timeoutsReversed) {

            bottomView.removeViewAt(0);

            bottomView.removeViewAt(1);

            bottomView.addView(bottomRightView, 0);

            bottomView.addView(bottomLeftView, 2);


            bottomLeftView.removeViewAt(0);

            bottomLeftView.removeViewAt(0);

            bottomLeftView.addView(homeSets, 0);

            bottomLeftView.addView(homeTimeoutLinear);


            bottomRightView.removeViewAt(0);

            bottomRightView.removeViewAt(0);

            bottomRightView.addView(awayTimeoutLinear, 0);

            bottomRightView.addView(awaySets);


            timeoutsReversed = true;

        }else{

            bottomView.removeViewAt(0);

            bottomView.removeViewAt(1);

            bottomView.addView(bottomLeftView, 0);

            bottomView.addView(bottomRightView, 2);


            bottomLeftView.removeViewAt(0);

            bottomLeftView.removeViewAt(0);

            bottomLeftView.addView(homeTimeoutLinear, 0);

            bottomLeftView.addView(homeSets);


            bottomRightView.removeViewAt(0);

            bottomRightView.removeViewAt(0);

            bottomRightView.addView(awaySets, 0);

            bottomRightView.addView(awayTimeoutLinear);

            timeoutsReversed = false;

        }

    }

    private void sendText() {

        PackageManager pm = this.getPackageManager();
        boolean hasTelephony = pm.hasSystemFeature(PackageManager.FEATURE_TELEPHONY);

        if(hasTelephony) {

            String messageOutline = String.valueOf(mySharedPreferences.getSMSMessage());

            String messageWithHome = messageOutline.replaceAll(Constants.HOME_SCORE, String.valueOf(VBMatch.getHomeScore()));

            String messageWithAway = messageWithHome.replaceAll(Constants.AWAY_SCORE, String.valueOf(VBMatch.getAwayScore()));

            int setNum = getSetNum();

            String messageWithSetNum = messageWithAway.replaceAll(Constants.SET, String.valueOf(setNum));

            int homeSetsWon = getHomeSets();

            int awaySetsWon = getAwaySets();

            final String messageWithHomeSets = messageWithSetNum.replaceAll(Constants.HOME_SETS, String.valueOf(homeSetsWon));

            final String messageWithAwaySets = messageWithHomeSets.replaceAll(Constants.AWAY_SETS, String.valueOf(awaySetsWon));

            final String messageWithHomeTeamName = messageWithAwaySets.replaceAll(Constants.HOME_TEAM_NAME, String.valueOf(mySharedPreferences.getHomeTeamName()));

            final String messageWithMyPlayer = messageWithHomeTeamName.replaceAll(Constants.MY_PLAYER, String.valueOf(mySharedPreferences.getMyPlayer()));

            final String messageWithMyPlayerName = messageWithMyPlayer.replaceAll(Constants.PLAYER_NAME, String.valueOf(mySharedPreferences.getMyPlayer()));

            final String message = messageWithMyPlayerName.replaceAll(Constants.AWAY_TEAM_NAME, String.valueOf(mySharedPreferences.getAwayTeamName()));

            if(mySharedPreferences.getAutoText() == Constants.OFF ){

                final LinearLayout numberLinear = new LinearLayout(this);

                LinearLayout smsView = new LinearLayout(this);

                smsView.setOrientation(LinearLayout.VERTICAL);

                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                params.setMargins(8, 0, 8, 0);

                numberLinear.setLayoutParams(params);

                TextView text = new TextView(this);

                LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);

                textParams.setMargins(8, 0, 0, 0);

                text.setLayoutParams(textParams);

                text.setGravity(Gravity.CENTER);

                text.setTextSize(17);

                text.setTextColor(Color.BLACK);

                text.setText(R.string.send_text_to);

                numberLinear.addView(text);

                final EditText numberField = new EditText(this);

                numberField.setLayoutParams(params);

                numberLinear.addView(numberField);

                numberField.setInputType(InputType.TYPE_CLASS_PHONE);

                numberField.setText(String.valueOf(mySharedPreferences.getNumbers()));


                LinearLayout messageLinear = new LinearLayout(this);

                messageLinear.setLayoutParams(params);

                final EditText messageEditText = new EditText(this);


                messageEditText.setText(message);

                messageEditText.setLayoutParams(params);

                messageLinear.addView(messageEditText);


                smsView.addView(messageLinear);
                smsView.addView(numberLinear);

                new AlertDialog.Builder(this)
                        .setTitle("Send Text Message")
                        .setMessage("You can edit your message below. You can change the default message outline in settings. If you want texts to be sent without this popup you can turn it off in settings.")
                        .setView(smsView)
                        .setPositiveButton("Send", (dialog, whichButton) -> {

                            mySharedPreferences.setNumbers(numberField.getText().toString());

                            if (mySharedPreferences.getNumbers().length() > 0 && messageEditText.getText().toString().length() > 0) {

                                ArrayList<String> numbers = new ArrayList<>(Arrays.asList(numberField.getText().toString().split(", *")));


                                /*for (String num : numbers) {
                                    sendSMSIntent( num, messageEditText.getText().toString());
                                    //SmsManager.getDefault().sendTextMessage(num, null, messageEditText.getText().toString(), null, null);
                                }*/

                                sendSMSIntent(numbers, messageEditText.getText().toString());

                                Toast.makeText(MainActivity.this, "Text sent", Toast.LENGTH_SHORT).show();
                            } else {

                                if(mySharedPreferences.getNumbers().length() == 0) {

                                    Toast.makeText(MainActivity.this, "Add at least one number and try again", Toast.LENGTH_LONG).show();

                                }else{

                                    Toast.makeText(MainActivity.this, "Please create a message with at least one character and try again", Toast.LENGTH_LONG).show();

                                }

                            }

                        })

                        .setNegativeButton(android.R.string.no, (dialog, which) -> mySharedPreferences.setNumbers(numberField.getText().toString())).show();
            }else{

                if (mySharedPreferences.getNumbers().length() > 0 && String.valueOf(mySharedPreferences.getSMSMessage()).length() > 0) {

                    ArrayList<String> numbers = new ArrayList<>(Arrays.asList(String.valueOf(mySharedPreferences.getNumbers()).split(", *")));


                    for (String num : numbers) {
                        SmsManager.getDefault().sendTextMessage(num, null, message, null, null);

                        Bundle bundle = new Bundle();
                        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "Background Message");
                        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "text");
                        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
                    }

                    Toast.makeText(MainActivity.this, "Text sent", Toast.LENGTH_SHORT).show();

                } else {

                    if(mySharedPreferences.getNumbers().length() == 0) {

                        Toast.makeText(MainActivity.this, "Add at least one number and try again", Toast.LENGTH_LONG).show();

                        Intent i = new Intent(MainActivity.this, EditNumbers.class);

                        startActivity(i);

                    }else{

                        Toast.makeText(MainActivity.this, "Please create a message with at least one character and try again", Toast.LENGTH_LONG).show();

                        Intent i = new Intent(MainActivity.this, EditSMS.class);

                        startActivity(i);

                    }
                }

            }

        }else{


            new AlertDialog.Builder(this)
                    .setTitle("Feature Unavailable")
                    .setMessage("You device does not seem to be able to send sms messages. If it can, you can contact the developer by emailing ajheschl@gmail.com " +
                            "to report this as an error")
                    .setPositiveButton("Ok", null)
                    .show();

        }

    }

    private void sendText(String message) {

        PackageManager pm = this.getPackageManager();
        boolean hasTelephony = pm.hasSystemFeature(PackageManager.FEATURE_TELEPHONY);

        if(hasTelephony) {

            final LinearLayout numberLinear = new LinearLayout(this);

            LinearLayout smsView = new LinearLayout(this);

            smsView.setOrientation(LinearLayout.VERTICAL);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

            params.setMargins(8, 0, 8, 0);

            numberLinear.setLayoutParams(params);

            TextView text = new TextView(this);

            LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);

            textParams.setMargins(8, 0, 0, 0);

            text.setLayoutParams(textParams);

            text.setGravity(Gravity.CENTER);

            text.setTextSize(17);

            text.setTextColor(Color.BLACK);

            text.setText(R.string.send_text_to);

            numberLinear.addView(text);

            final EditText numberField = new EditText(this);

            numberField.setLayoutParams(params);

            numberLinear.addView(numberField);

            numberField.setInputType(InputType.TYPE_CLASS_PHONE);

            numberField.setText(String.valueOf(mySharedPreferences.getNumbers()));


            LinearLayout messageLinear = new LinearLayout(this);

            messageLinear.setLayoutParams(params);

            final EditText messageEditText = new EditText(this);

            messageEditText.setText(message);

            messageEditText.setLayoutParams(params);

            messageLinear.addView(messageEditText);


            smsView.addView(messageLinear);
            smsView.addView(numberLinear);

            new AlertDialog.Builder(this)
                    .setTitle("Send Text Message")
                    .setMessage("You can stop this popup by turning it off in settings. You can edit your message below.")
                    .setView(smsView)
                    .setPositiveButton("Send", (dialog, whichButton) -> {

                        mySharedPreferences.setNumbers(numberField.getText().toString());

                        if (mySharedPreferences.getNumbers().length() > 0) {

                            ArrayList<String> numbers = new ArrayList<>(Arrays.asList(numberField.getText().toString().split(", *")));


                            /*for (String num : numbers) {

                                //SmsManager.getDefault().sendTextMessage(num, null, messageEditText.getText().toString(), null, null);
                                sendSMSIntent(num, messageEditText.getText().toString());

                            }*/

                            sendSMSIntent(numbers, messageEditText.getText().toString());

                            Toast.makeText(MainActivity.this, "Text sent", Toast.LENGTH_SHORT).show();
                        } else {

                            Toast.makeText(MainActivity.this, "Add at least one number and try again", Toast.LENGTH_LONG).show();

                        }


                    }).setNegativeButton(android.R.string.no, (dialog, which) -> mySharedPreferences.setNumbers(numberField.getText().toString())).show();

        }else{


            new AlertDialog.Builder(this)
                    .setTitle("Feature Unavailable")
                    .setMessage("You device does not seem to be able to send sms messages. If it can, you can contact the developer by emailing ajheschl@gmail.com " +
                            "to report this as an error")
                    .setPositiveButton("Ok", null)
                    .show();

        }

    }

    private void sendTextNoConfirmEndOfSet(String setOrMatch, String winningTeam){

        String messageOutline = String.valueOf(mySharedPreferences.getSMSMessagePostSet());

        final String message = getMessage(messageOutline, winningTeam, setOrMatch);

        PackageManager pm = this.getPackageManager();
        boolean hasTelephony = pm.hasSystemFeature(PackageManager.FEATURE_TELEPHONY);

        if(hasTelephony) {

            if (mySharedPreferences.getNumbers().length() > 0) {

                ArrayList<String> numbers = new ArrayList<>(Arrays.asList(mySharedPreferences.getNumbers().split(", *")));

                /*for (String num : numbers) {

                    sendSMSIntent(num, message);

                }*/

                sendSMSIntent(numbers, message);

                Toast.makeText(MainActivity.this, "Text sent", Toast.LENGTH_SHORT).show();
            } else {

                Toast.makeText(MainActivity.this, "Add at least one number and try again", Toast.LENGTH_LONG).show();

            }

        }else{

            new AlertDialog.Builder(this)
                    .setTitle("Feature Unavailable")
                    .setMessage("You device does not seem to be able to send sms messages. If it can, you can contact the developer by emailing ajheschl@gmail.com " +
                            "to report this as an error")
                    .setPositiveButton("Ok", null)
                    .show();

        }

    }

    private int getAwaySets() {

        int sets;

        sets = mySharedPreferences.getAwaySetsWon();

        return sets;
    }

    private int getHomeSets() {

        int sets;

        sets = mySharedPreferences.getHomeSetsWon();

        return sets;

    }

    private void resetGame() {

        VBMatch.setHomeScore(0);
        VBMatch.setAwayScore(0);

        mySharedPreferences.setAwayScore(VBMatch.getAwayScore());

        mySharedPreferences.setHomeScore(VBMatch.getHomeScore());

        homeButton.setText(String.valueOf(VBMatch.getHomeScore()));

        awayButton.setText(String.valueOf(VBMatch.getAwayScore()));

        if(homeButtonIndex != 0){
            changeSides();
        }

        rightIndicator.setVisibility(View.VISIBLE);

        leftIndicator.setVisibility(View.VISIBLE);

        homeTimeout1.setChecked(false);

        homeTimeout2.setChecked(false);

        awayTimeout1.setChecked(false);

        awayTimeout2.setChecked(false);

        mySharedPreferences.setHomeSetsWon(0);

        mySharedPreferences.setAwaySetsWon(0);

        homeSetNumber.setText(String.valueOf(mySharedPreferences.getHomeScore()));

        awaySetNumber.setText(String.valueOf(mySharedPreferences.getAwayScore()));

        setNumber.setText(String.valueOf(getSetNum()));

        mySharedPreferences.setServer(Constants.NEUTRAL);

        setHistoryShared.setFirstSetHistory("");
        setHistoryShared.setSecondSetHistory("");
        setHistoryShared.setThirdSetHistory("");
        setHistoryShared.setFourthSetHistory("");
        setHistoryShared.setFifthSetHistory("");

        showSetHistory();

    }

    private void initScores() {

        VBMatch.setHomeScore(mySharedPreferences.getHomeScore());
        VBMatch.setAwayScore(mySharedPreferences.getAwayScore());

    }

    @SuppressLint("ClickableViewAccessibility")
    private void initScoreButtons() {

        homeButton2 = findViewById(R.id.homeScore2);

        awayScore2 = findViewById(R.id.awayScore2);

        homeButton = findViewById(R.id.homeScore);
        awayButton = findViewById(R.id.awayScore);

        leftIndicator = findViewById(R.id.leftServeIndicator);

        rightIndicator = findViewById(R.id.rightServeIndicator);

        homeButton.setText(String.valueOf(mySharedPreferences.getHomeScore()));
        awayButton.setText(String.valueOf(mySharedPreferences.getAwayScore()));

        homeButtonDetector = new GestureDetector(this, new OnSwipeListener(){

            @Override
            boolean onSwipe(Direction direction) {
                if (direction==Direction.up){
                    VBMatch.homeScoreUp(MainActivity.this);
                }

                if (direction==Direction.down){
                    VBMatch.homeScoreDown(MainActivity.this);
                }

                return true;
            }

            @Override
            public boolean onTapConfirmed(MotionEvent event){

                VBMatch.homeScoreUp(MainActivity.this);
                return true;
            }

            @Override
            public boolean onLongPressConfirmed(MotionEvent event){

                AmbilWarnaDialog dialog = new AmbilWarnaDialog(MainActivity.this, mySharedPreferences.getHomeColor(), new AmbilWarnaDialog.OnAmbilWarnaListener(){
                    @Override
                    public void onOk(AmbilWarnaDialog dialog, int color) {
                        mySharedPreferences.setHomeColor(color);
                        initButtonColors();
                    }

                    @Override
                    public void onCancel(AmbilWarnaDialog dialog) {
                        // cancel was selected by the user
                    }
                });

                dialog.show();

                return true;
            }


        });

        awayButtonDetector = new GestureDetector(this, new OnSwipeListener(){

            @Override
            boolean onSwipe(Direction direction) {
                if (direction==Direction.up){
                    VBMatch.awayScoreUp(MainActivity.this);
                }

                if (direction==Direction.down){
                    VBMatch.awayScoreDown(MainActivity.this);
                }

                return true;
            }
            
            @Override
            public boolean onTapConfirmed(MotionEvent event){
                VBMatch.awayScoreUp(MainActivity.this);
                return true;
            }

            @Override
            public boolean onLongPressConfirmed(MotionEvent event){

                // initialColor is the initially-selected color to be shown in the rectangle on the left of the arrow.
                // for example, 0xff000000 is black, 0xff0000ff is blue. Please be aware of the initial 0xff which is the alpha.
                AmbilWarnaDialog dialog = new AmbilWarnaDialog(MainActivity.this, mySharedPreferences.getAwayColor(), new AmbilWarnaDialog.OnAmbilWarnaListener(){
                    @Override
                    public void onOk(AmbilWarnaDialog dialog, int color) {
                        mySharedPreferences.setAwayColor(color);
                        initButtonColors();
                    }

                    @Override
                    public void onCancel(AmbilWarnaDialog dialog) {
                        // cancel was selected by the user
                    }
                });

                dialog.show();
                return true;
            }


        });

        homeButton.setOnTouchListener(this);

        awayButton.setOnTouchListener(this);

        slideUpHome = AnimationUtils.loadAnimation(this, R.anim.slide_up_out);

        slideUpHome.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

                if(Integer.parseInt(homeButton.getText().toString()) < VBMatch.getHomeScore() - 1){
                    homeButton.setText(String.valueOf(mySharedPreferences.getHomeScore() - 1));
                }

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                homeButton.setText(String.valueOf(mySharedPreferences.getHomeScore()));
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });


        slideDownHome = AnimationUtils.loadAnimation(this, R.anim.slide_down_out);

        slideDownHome.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                if(Integer.parseInt(homeButton.getText().toString()) > VBMatch.getHomeScore() - 1){
                    homeButton.setText(String.valueOf(mySharedPreferences.getHomeScore() + 1));
                }
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                homeButton.setText(String.valueOf(mySharedPreferences.getHomeScore()));
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });


        slideUpAway = AnimationUtils.loadAnimation(this, R.anim.slide_up_out);

        slideUpAway.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

                if(Integer.parseInt(awayButton.getText().toString()) < VBMatch.getAwayScore() - 1){
                    awayButton.setText(String.valueOf(mySharedPreferences.getAwayScore() - 1));
                }

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                awayButton.setText(String.valueOf(mySharedPreferences.getAwayScore()));
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });


        slideDownAway = AnimationUtils.loadAnimation(this, R.anim.slide_down_out);

        slideDownAway.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                if(Integer.parseInt(awayButton.getText().toString()) > VBMatch.getAwayScore() - 1){
                    awayButton.setText(String.valueOf(mySharedPreferences.getAwayScore() + 1));
                }
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                awayButton.setText(String.valueOf(mySharedPreferences.getAwayScore()));
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

    }

    boolean isTieBreaker() {

        boolean isTieBreaker = false;
        if(mySharedPreferences.gettNumberOfSets() == 5){

            if(getSetNum() == 5){
                isTieBreaker = true;
            }

        }else{

            if(getSetNum() == 3){
                isTieBreaker = true;
            }

        }

        return isTieBreaker;

    }

    void displayWin(final String team) {

        if(team.equals("away")) {

            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Game over")
                    .setMessage(mySharedPreferences.getAwayTeamName() + " won the match")
                    .setPositiveButton("Prepare new match", (dialog, which) -> {

                        if(mySharedPreferences.getSMSPopup() == Constants.ON) {
                            sendText(getMessage(mySharedPreferences.getSMSMessagePostSet(), mySharedPreferences.getAwayTeamName(), Constants.MATCH));
                        }else{
                            sendTextNoConfirmEndOfSet(Constants.MATCH, mySharedPreferences.getAwayTeamName());
                        }

                        resetGame();

                    })
                    .setNegativeButton("Cancel", (dialog, which) -> {

                        if(mySharedPreferences.gettNumberOfSets() == 3){

                            awaySetNumber.setText("1");

                            mySharedPreferences.setAwaySetsWon(1);

                        }else{

                            awaySetNumber.setText("2");

                            mySharedPreferences.setAwaySetsWon(2);

                        }
                    }).setCancelable(false)
                    .show();
        }else{

            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Game over")
                    .setMessage(mySharedPreferences.getHomeTeamName() + " won the match!")
                    .setPositiveButton("Prepare new match", (dialog, which) -> {

                        if(mySharedPreferences.getSMSPopup() == Constants.ON) {
                            sendText(getMessage(mySharedPreferences.getSMSMessagePostSet(), mySharedPreferences.getHomeTeamName(), Constants.MATCH));
                        }else{
                            sendTextNoConfirmEndOfSet(Constants.MATCH, mySharedPreferences.getHomeTeamName());
                        }

                        resetGame();

                    })
                    .setNegativeButton("Cancel", (dialog, which) -> {

                        if(mySharedPreferences.gettNumberOfSets() == 3){
                            homeSetNumber.setText("1");

                            mySharedPreferences.setHomeSetsWon(1);
                        }else{

                            homeSetNumber.setText("2");

                            mySharedPreferences.setHomeSetsWon(2);

                        }

                    }).setCancelable(false)
                    .show();

        }

    }

    private int getSetNum(){

        int setNum = 1;

        setNum += mySharedPreferences.getHomeSetsWon();

        setNum += mySharedPreferences.getAwaySetsWon();

        return setNum;

    }

    @Override
    protected void onPause() {

        mySharedPreferences.setHomeButtonIndex(homeButtonIndex);

        super.onPause();
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouch(View view, MotionEvent event) {
        
        if(view == homeButton){
            return homeButtonDetector.onTouchEvent(event);
        } else{
            return awayButtonDetector.onTouchEvent(event);
        }
    
    }
}
